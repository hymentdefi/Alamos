# Álamos · Logos

Carpeta lista para usar. Cada archivo tiene fondo transparente (excepto los app-icons que son cuadrados con su fondo de color).

## Estructura

### `iso/` — Símbolo solo (los dos triángulos)
- `alamos-iso-verde.svg/png` — ambos triángulos verdes
- `alamos-iso-blanco.svg/png` — ambos triángulos blancos
- `alamos-iso-negro.svg/png` — ambos triángulos negros
- `alamos-iso-duo-verde-negro.svg/png` — back verde + front negro
- `alamos-iso-duo-verde-blanco.svg/png` — back verde + front blanco
- `alamos-iso-solid-verde-negro.svg/png` — versión rellena
- `alamos-iso-solid-verde-blanco.svg/png` — versión rellena

### `lockups/` — Iso + nombre (los dos triángulos siempre verdes)
4 sub-marcas × 3 colores de texto:
- `alamos-{texto-verde, texto-blanco, texto-negro}`
- `alamos-capital-{texto-verde, texto-blanco, texto-negro}`
- `alamos-academy-{texto-verde, texto-blanco, texto-negro}`
- `alamos-empresas-{texto-verde, texto-blanco, texto-negro}`

Los SVG tienen Plus Jakarta Sans 700 **embebida** — no necesitás tenerla instalada.

### `app-icons/` — 1024×1024, cuadrado redondeado iOS
- `alamos-app-icon-claro.svg/png` — fondo claro, iso verde outline
- `alamos-app-icon-oscuro-verde.svg/png` — fondo negro, iso verde
- `alamos-app-icon-oscuro-blanco.svg/png` — fondo negro, iso blanco
- `alamos-app-icon-verde-blanco.svg/png` — fondo verde, iso blanco
- `alamos-app-icon-outline-bold.svg/png` — fondo claro, back verde + front negro

## Formatos

- **SVG** — vectorial, escalable a cualquier tamaño sin pérdida. Para web, app, print.
- **PNG** — raster en alta resolución. Iso/app-icons en 1024px; lockups en 2000px de ancho.

## Color
- Verde: `#00E676`
- Negro: `#0E0F0C`
- Blanco/claro: `#FAFAF7`
